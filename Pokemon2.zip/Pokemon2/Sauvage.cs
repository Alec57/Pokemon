﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon2
{
    public class Sauvage : Entité
    {
        public Sauvage(string nom) : base(nom)
        {
            this.nom = nom;
            this.pointsDeVie = 50;
            this.degatsMin = 10;
            this.degatsMax = 40;
            this.vitesse = 2;



        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon2
{
    public class Salameche : Personnage
    {
        public Salameche(string nom) : base(nom)
        {
            pointsDeVie = 100;
            degatsMin = 25;
            degatsMax = 50;
            vitesse = 5;
        }

            

    }
}
